import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import datetime as dt
import matplotlib.dates as mdates
import sys


def main():
    filePath = sys.argv[1]
    directoryOfDeaths = sys.argv[2]
    directoryOfConfAndRecov = sys.argv[3]
    # provide file path to the countries-aggregated.csv
    attDF = pd.read_csv(filePath)
    print(attDF.head())
    countryList = attDF['Country'].to_list()
    countrySet = set(countryList)
    print(countrySet)
    for country in countrySet:

        country_DF = attDF[attDF['Country'] == country]
        dates = country_DF['Date']
        for field in ['Confirmed', 'Recovered']:
            x = [dt.datetime.strptime(d, '%Y-%m-%d').date() for d in dates]
            plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%m/%d/%Y'))
            plt.gca().xaxis.set_major_locator(mdates.DayLocator(interval=30))
            plt.plot(x, country_DF[field], label=field)
            plt.gcf().autofmt_xdate()
            plt.xlabel('date')

            plt.title(country)

        plt.legend()
        # create directories Plots/RecoveredAndConfirmed to save the plots
        plt.savefig("{}/{}_Rec_Con.png".format(directoryOfConfAndRecov, country))
        plt.close()
        plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%m/%d/%Y'))
        plt.gca().xaxis.set_major_locator(mdates.DayLocator(interval=30))
        plt.plot(x, country_DF['Deaths'], label='Deaths')
        plt.gcf().autofmt_xdate()
        plt.xlabel('date')
        plt.ylabel('Deaths')
        plt.title(country)
        # create directories Plots/Death to save the plots
        plt.savefig("{}/{}_Deaths.png".format(directoryOfDeaths, country))
        plt.close()


if __name__ == '__main__':
    main()

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
