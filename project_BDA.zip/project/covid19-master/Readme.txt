﻿The generatePlot.py  program takes three command-line arguments the first is the countries-aggregated.csv file of the data the second is the file path to save the recovered and confirmed cases plot and the third is the directory for the number of deaths plot.




For project720.py:
Save the csv files in a directory called dataset
Input the country, weather condition(humidity_mean,mean_uv...), and status(deaths,confirmed, recovered) when prompted